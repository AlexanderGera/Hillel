let userName = prompt('What is your name?');
alert(`Hello, ${userName}! How are you?`);