'use strict';
//first Task

let firstString = prompt('What is the first string?');
let secondString = prompt('What is the second string?');
let thirdString = prompt('What is the third string?');

alert(`You just wrote: ${firstString} ${secondString} ${thirdString}`);

//second Task

let customersNumber = 12345;

let customersNumberModification = customersNumber.toString().split('').join(' ');

alert(`Second Task: ${customersNumberModification}`);




